/* This file is created by MySQLReback 2015-12-28 09:04:18 */
 /* 创建表结构 `webster_baoming` */
 DROP TABLE IF EXISTS `webster_baoming`;/* MySQLReback Separation */ CREATE TABLE `webster_baoming` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT '姓名',
  `mynum` varchar(30) DEFAULT NULL COMMENT '号牌',
  `phone` varchar(11) DEFAULT '' COMMENT '手机号码',
  `touxiang` text COMMENT '头像',
  `count` float(10,0) DEFAULT '0' COMMENT '当前票数',
  `usort` varchar(255) DEFAULT '0' COMMENT '排序',
  `status` int(11) DEFAULT '0' COMMENT '状态 1 正常 0 未审核',
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='报名表';/* MySQLReback Separation */
 /* 插入数据 `webster_baoming` */
 INSERT INTO `webster_baoming` VALUES ('1','测试人员1','10010','17095135001','/Public/Uploads/2015-12-25/567cccadb1989.png','9','0','1','2015-12-25 12:57:19'),('2','测试人员2','10011','17095135002','/Public/Uploads/2015-12-25/567cccc2b67df.png','14','0','1','2015-12-25 12:57:40'),('3','测试人员3','10012','17095135003','/Public/Uploads/2015-12-25/567cccd9860d2.png','334','0','1','2015-12-25 12:58:03'),('4','测试人员4','10013','17095135004','/Public/Uploads/2015-12-25/567cccee6ff40.png','4','0','1','2015-12-25 12:58:24'),('5','测试人员5','10014','17095135005','/Public/Uploads/2015-12-25/567d011fc71cc.png','3','0','1','2015-12-25 12:58:45'),('6','测试人员6','10015','17095135006','/Public/Uploads/2015-12-25/567ccdb0a2d1c.png','22','0','1','2015-12-25 13:01:38'),('7','测试人员7','10016','17095135007','/Public/Uploads/2015-12-25/567ccdf50ec07.jpg','43','0','1','2015-12-25 13:02:46'),('8','测试人员8','10017','17095135008','/Public/Uploads/2015-12-25/567cce26b0fc7.jpg','158','0','1','2015-12-25 13:03:36'),('9','测试人员9','10018','17095135009','/Public/Uploads/2015-12-25/567cf9d067687.png','4','0','1','2015-12-25 16:09:53'),('10','测试店员10','10019','17095135002','/Public/Uploads/2015-12-26/567e26b40e79c.png','0','0','1','2015-12-26 13:33:37'),('11','测试店员11','10020','17095135002','/Public/Uploads/2015-12-26/567e2728888f0.png','0','0','1','2015-12-26 13:35:34'),('12','测试店员12','10021','17095135002','/Public/Uploads/2015-12-26/567e2745805c6.png','0','0','1','2015-12-26 13:36:03'),('13','测试店员13','10022','17095135002','/Public/Uploads/2015-12-26/567e27617dfe3.png','0','0','1','2015-12-26 13:36:31'),('14','测试店员14','10023','17095135002','/Public/Uploads/2015-12-26/567e277478095.png','0','0','1','2015-12-26 13:36:50'),('15','测试店员15','10024','17095135002','/Public/Uploads/2015-12-27/567fc1ee35714.png','0','0','1','2015-12-26 13:37:37'),('16','测试店员16','1100171','17095135002','/Public/Uploads/2015-12-26/567e27db86e5e.png','0','0','1','2015-12-26 13:38:33'),('17','测试店员16','110025','17095135002','/Public/Uploads/2015-12-26/567e283f7a0fa.png','0','0','1','2015-12-26 13:40:13'),('18','测试人员17','10026','17095135002','/Public/Uploads/2015-12-26/567e28560b5e4.png','0','0','1','2015-12-26 13:40:35'),('19','测试员工15','123456','17095135002','/Public/Uploads/2015-12-27/567fc1e4c633e.png','0','0','1','2015-12-27 15:11:01'),('20','试试','123','11111111111','/Public/Uploads/2015-12-27/567fc1f90c03d.png','0','0','1','2015-12-27 15:15:57'),('21','王','11','13313309090','/Public/Uploads/2015-12-27/567fc203b1d31.png','0','0','1','2015-12-27 15:23:37'),('22','张三','123586','17095135002','/Public/Uploads/2015-12-27/1451204469.jpg','0','0','1','2015-12-27 16:21:32'),('23','xbox','88552P','13223123123','/Public/Uploads/2015-12-27/1451205791.jpg','1','0','1','2015-12-27 16:43:47'),('24','euu','2223P','13213211332','/Public/Uploads/2015-12-27/1451218652.jpg','0','0','0','2015-12-27 20:18:03');/* MySQLReback Separation */
 /* 创建表结构 `webster_setscreen` */
 DROP TABLE IF EXISTS `webster_setscreen`;/* MySQLReback Separation */ CREATE TABLE `webster_setscreen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `screen_logo` text COMMENT '大屏logo',
  `screen_music` text COMMENT '音乐外链',
  `screen_video` text COMMENT '视频外链',
  `is_music` int(11) DEFAULT NULL COMMENT '是否开启音乐',
  `is_video` int(11) DEFAULT NULL COMMENT '是否开启视频',
  `is_screen` int(11) DEFAULT NULL COMMENT '是否开启大屏',
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='大屏设置';/* MySQLReback Separation */
 /* 插入数据 `webster_setscreen` */
 INSERT INTO `webster_setscreen` VALUES ('1','/Public/Uploads/2015-12-26/567ea8e19a9df.png','http://qzone.haoduoge.com/music/4C5FAF5IZQ94AB32170BF0F8F54ECA053840C.mp3','http://player.youku.com/embed/XMjY3MzgzODg0','1','1','1','2015-12-27 13:08:53');/* MySQLReback Separation */
 /* 创建表结构 `webster_siteinfo` */
 DROP TABLE IF EXISTS `webster_siteinfo`;/* MySQLReback Separation */ CREATE TABLE `webster_siteinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sitename` varchar(255) DEFAULT NULL COMMENT '网站名称',
  `siteurl` text COMMENT '网站网址',
  `sitelogo` text COMMENT '网站logo',
  `sitedesc` text COMMENT '网站描述',
  `sitekeywords` text COMMENT '网站关键词',
  `siteicp` varchar(255) DEFAULT NULL COMMENT '网站备案号码',
  `sitecode` text COMMENT '网站统计代码',
  `sitestatus` int(11) DEFAULT NULL COMMENT '网站状态',
  `statusdesc` text COMMENT '网站关闭原因',
  `active_info` text NOT NULL COMMENT '活动介绍',
  `vip_info` text NOT NULL COMMENT '奖品设置',
  `rule_info` text NOT NULL COMMENT '活动规则',
  `vote_rule` text NOT NULL COMMENT '投票规则',
  `vote_status` int(11) NOT NULL DEFAULT '0' COMMENT '是否开启投票',
  `gs_title` varchar(255) DEFAULT NULL COMMENT '公示标题',
  `gs_content` text COMMENT '公示内容',
  `gs_status` varchar(255) NOT NULL DEFAULT '0' COMMENT '是否开启公示',
  `vote_btime` int(11) DEFAULT NULL COMMENT '投票开始时间',
  `vote_etime` int(11) DEFAULT NULL COMMENT '投票结束时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='网站基本信息表';/* MySQLReback Separation */
 /* 插入数据 `webster_siteinfo` */
 INSERT INTO `webster_siteinfo` VALUES ('1','年会投票','toupiao.580bang.com','/Public/Uploads/2015-12-25/567cd4a3b9927.png','年会投票','年会投票','苏ICP备14010218号','','1','为了能让您访问更快更稳定，同时为您提供更高品质的服务，我们正在维护系统。因此目前网站的部分功能不能使用，请稍后再回来。给您造成了不便，请谅解!','年会投票','年会投票','年会投票','&lt;p&gt;
	&lt;span style=&quot;line-height:2;font-size:14px;&quot;&gt;1、投票时间：2015年10月15日0:00~2015年10月24日24:00&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;line-height:2;font-size:14px;&quot;&gt; 2、每位用户每天可以投5票，但是每天只能给同一作品投1票。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;line-height:2;font-size:14px;&quot;&gt; 3、我们会对活动投票全程监控，如发现非正常投票及刷票行为，将取消投票者所有票数，情节严重者，将取消相关参赛者的参赛资格。&lt;/span&gt; 
&lt;/p&gt;','1','','&lt;p style=&quot;text-align:justify;text-indent:20pt;margin-left:0pt;&quot; class=&quot;MsoNormal&quot;&gt;
	&lt;br /&gt;
&lt;/p&gt;','1','1451025144','1451543544');/* MySQLReback Separation */
 /* 创建表结构 `webster_user` */
 DROP TABLE IF EXISTS `webster_user`;/* MySQLReback Separation */ CREATE TABLE `webster_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` char(32) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态 1:启用 0:禁止',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `last_login_time` int(11) unsigned NOT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(15) NOT NULL DEFAULT '' COMMENT '最后登录IP',
  `login_time` int(11) unsigned NOT NULL COMMENT '最后登录时间',
  `login_ip` varchar(15) NOT NULL DEFAULT '' COMMENT '登录IP',
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;/* MySQLReback Separation */
 /* 插入数据 `webster_user` */
 INSERT INTO `webster_user` VALUES ('1','Webster','5c2a8d4350404a979d655cff223d3d4e','1','123','1451217619','202.102.85.18','1451264622','202.102.85.18'),('2','admin','434d711276d2ed2068e7a02499fac15c','1','','1451218703','202.102.85.21','1451218787','202.102.85.21');/* MySQLReback Separation */
 /* 创建表结构 `webster_vote` */
 DROP TABLE IF EXISTS `webster_vote`;/* MySQLReback Separation */ CREATE TABLE `webster_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cookie_id` varchar(255) DEFAULT NULL COMMENT '微信是openid，电脑是cookie',
  `ipaddr` varchar(255) DEFAULT NULL COMMENT '投票的ip地址',
  `b_id` int(11) DEFAULT NULL COMMENT '报名对象对应的id',
  `time` int(11) DEFAULT NULL COMMENT '投票时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='投票记录表';/* MySQLReback Separation */
 /* 插入数据 `webster_vote` */
 INSERT INTO `webster_vote` VALUES ('1','7679edfc91d8f0ef7badcc5266741091','192.168.1.107','6','1451028215'),('2','c3dfeeaf05dc4bf6838ef2bca2545bd9','222.73.144.27','2','1451190492'),('3','7cd83abea76b6ca58bb956a78206a8d9','222.73.144.29','5','1451195276'),('4','e1ffe63b60c50849c829f744face4b6c','202.102.85.22','2','1451199328'),('5','916a767f6045d683289b1298fbf765c6','202.102.85.21','23','1451219689');/* MySQLReback Separation */